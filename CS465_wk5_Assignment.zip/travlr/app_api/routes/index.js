const express = require("express"); //express app
const router = express.Router(); //router logic

//import controllers
const tripsController = require("../controllers/trips");

//define route for trips endpoint
router
    .route("/trips")
    .get(tripsController.tripsList);

//get method routes tripsFindByCode
router
    .route('/trips/:tripCode')
    .get(tripsController.tripsFindByCode);

module.exports = router;